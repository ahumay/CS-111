#!/bin/bash
python lab3b.py $1